from brownie import accounts

def main():
    return accounts



# accounts[1].transfer("0x926AE5fae1Efa57545CC57bcfA434203be9c8794", 300000000)